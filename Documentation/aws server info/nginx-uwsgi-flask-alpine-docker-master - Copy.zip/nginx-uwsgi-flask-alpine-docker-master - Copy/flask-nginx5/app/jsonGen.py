#!/usr/bin/python

import json
import math
from template import canvas

class JsonGenerator:
    def __init__(self, jsonFileName):
        self.nodes = set()
        self.nodeDesc = {}
        self.nodeColor = {}
        self.nodeShape = {}
        self.edges = set()
        self.jsonFileName = jsonFileName

        self.DEFAULT_COLOR    = '#283747'
        self.TBD_COLOR        = '#283747'
        self.PERMITS_COLOR    = '#00ff00'
        self.PROHIBITS_COLOR = '#ff0000'
        self.DEMANDS_COLOR    = '#00bbc3'
        self.REF_COLOR = '#4b0082'
        self.XOR_COLOR = '#8b4513'

        self.DEFAULT_SHAPE = 'ellipse'
        self.CONDITION_SHAPE = 'star'
        self.XOR_SHAPE = 'triangle'
        self.REF_SHAPE = 'square'     

        self.code1 = canvas.code1
        self.code2 = canvas.code2
        self.code3 = canvas.code3


    def genCode(self):
        ret = ""
        ret += self.code1
        for n in self.nodes:
            ret += '{ data: { id: "%s", name: "%s", color: "%s", shape: "%s"} },\n' % (n, self.nodeDesc[n], self.nodeColor[n], self.nodeShape[n])
        ret += self.code2
        for e in self.edges:
            ret += '{ data: { source: "%s", target: "%s" } },' % (e[0], e[1])
        ret += self.code3
        return ret
        
    def addNode(self, parentName="", desc=""):
        if desc == "XOR":
            nodeName = parentName
            self.nodeShape[nodeName] = self.XOR_SHAPE
            self.nodeColor[nodeName] = self.XOR_COLOR
        else:
            nodeName = "n%03d" % len(self.nodes)
            self.nodes.add(nodeName)
            if desc == "参照" or desc == "References":
                self.nodeColor[nodeName] = self.REF_COLOR
                self.nodeShape[nodeName] = self.REF_SHAPE
            else:
                self.nodeColor[nodeName] = self.DEFAULT_COLOR
                self.nodeShape[nodeName] = self.DEFAULT_SHAPE
            if parentName != "":
                self.edges.add((parentName, nodeName))
            self.nodeDesc[nodeName] = ""
            if desc != "":
                self.nodeDesc[nodeName] = desc
        return nodeName

    def line_splitter(self, text):
        """
        splits the given text up if it's in Japanese.
        Otherwise, just returns the text because it doesn't need to be split.
        Basically a hack to auto-wrap text (since Japanese has no spaces),
        but ignore if it is English
        """
        min_len = 30
        wrap_cutoff = min_len - 5
        if len(text) >= min_len and self.jsonFileName == "benchmark.json":
            #(The Japanese versions should be called benchmark.json)
            num = math.ceil(len(text) / min_len)
            newlined_data = text[0:wrap_cutoff]
            for i in range(1,num):
                newlined_data = newlined_data[0:i*wrap_cutoff] + '\\n' + text[i*wrap_cutoff:]
            #might cause a bug if tmpParentName is expected to
            #be the same as e, or something
            return newlined_data
        else:
            return text
        
    def dfs(self, data, parentName="", desc=""):
        print(len(desc))
        print(len(parentName))
        nodeName = self.addNode(parentName, self.line_splitter(desc))
        if type(data) == type({}):
            if "note" in data:
                del data["note"]
            if "コメント" in data:
                del data["コメント"]
            #Comment out to show references
            #if "参照" in data:
            #    del data["参照"]
            #if "References" in data:
            #    del data["References"]
            #
            #for leaf nodes
            for e in data:
                if type(data[e]) == type(u"string"):
                    tmpParentName = self.addNode(nodeName, self.line_splitter(e))
                    leafName = self.addNode(tmpParentName, self.line_splitter(data[e]))
                    if data[e] == "Demands" or data[e] == "必須":
                        self.nodeColor[leafName] = self.DEMANDS_COLOR
                        self.nodeColor[tmpParentName] = self.DEMANDS_COLOR
                    elif data[e] == "Permits" or data[e] == "非倫理的ではない":
                        self.nodeColor[leafName] = self.PERMITS_COLOR
                        self.nodeColor[tmpParentName] = self.PERMITS_COLOR
                    elif data[e] == "Prohibits" or data[e] == "禁止":
                        self.nodeColor[leafName] = self.PROHIBITS_COLOR
                        self.nodeColor[tmpParentName] = self.PROHIBITS_COLOR
                    elif data[e] == "TBD":
                        self.nodeColor[leafName] = self.TBD_COLOR
                        self.nodeColor[tmpParentName] = self.TBD_COLOR
                    #node name is the parent node
                    elif self.nodeColor[nodeName] == self.REF_COLOR:
                        #leafname is the leaf/right side
                        self.nodeColor[leafName] = self.REF_COLOR
                        #tmpParentName is the left side of the node
                        self.nodeColor[tmpParentName] = self.REF_COLOR
                    if e == "Condition":
                        self.nodeShape[tmpParentName] = self.CONDITION_SHAPE
                    elif e == "XOR":
                        self.nodeColor[leafName] = self.XOR_COLOR
                        
                else:
                    self.dfs(data[e], nodeName, self.line_splitter(e))
        elif type(data) == type([]):
            for e in data:
                print(e)
                self.dfs(e, nodeName)