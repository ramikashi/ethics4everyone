#! /bin/bash
FLASK_APP=app.py flask run
