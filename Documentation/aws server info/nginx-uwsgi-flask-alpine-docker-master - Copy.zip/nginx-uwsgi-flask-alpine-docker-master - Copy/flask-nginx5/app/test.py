import json

from template import foo

print foo.bar

# with open("../data/benchmark.json", "r") as fd:
#     data = json.load(fd)

# for e in data["Category"]["Human Subjects Testing and REBs/IRBs"]:
#     #print '<option value="%s">%s</option>' % (e, e)
#     print e

    
